# R.T Music cloud APK build

This repository is designed to build the Android APK using GitHub Actions, without a PC.

## Files to upload
Upload the contents of this folder to the root of a new private GitHub repository:
- `.github/workflows/build-apk.yml`
- `lib/main.dart`
- `pubspec.yaml`
- `assets/rt_music_icon.png`

## Run the build
The workflow runs automatically after a push to `main`, and can also be started manually:
1. Open the repository on GitHub.
2. Tap **Actions**.
3. Select **Build R.T Music APK**.
4. Tap **Run workflow** (if shown) and confirm.
5. Wait for the run to finish with a green check mark.
6. Open that completed run and scroll to **Artifacts**.
7. Download `rt-music-android-apk`; extract it to get `app-release.apk`.

## Important
- Keep the repository private if you want the source code private.
- GitHub Actions availability and usage limits depend on your account and repository settings.
- The APK loads https://rtmusic2.lovable.app online; it is not an offline music downloader.
- The build can fail if the website requires additional native integration or a dependency changes.
